.class La/b/a/a/fe;
.super Ljava/lang/Object;


# instance fields
.field private final a:La/b/a/a/fg;

.field private final b:Ljava/lang/reflect/Constructor;


# direct methods
.method public constructor <init>(Ljava/lang/reflect/Constructor;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, La/b/a/a/fg;

    invoke-direct {v0}, La/b/a/a/fg;-><init>()V

    iput-object v0, p0, La/b/a/a/fe;->a:La/b/a/a/fg;

    iput-object p1, p0, La/b/a/a/fe;->b:Ljava/lang/reflect/Constructor;

    return-void
.end method

.method private a(La/b/a/a/fg;)Ljava/util/List;
    .locals 1

    iget-object v0, p0, La/b/a/a/fe;->a:La/b/a/a/fg;

    invoke-virtual {v0}, La/b/a/a/fg;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, La/b/a/a/fe;->c()Ljava/util/List;

    move-result-object v0

    :goto_0
    return-object v0

    :cond_0
    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, La/b/a/a/fe;->a(La/b/a/a/fg;I)V

    invoke-direct {p0, p1}, La/b/a/a/fe;->b(La/b/a/a/fg;)Ljava/util/List;

    move-result-object v0

    goto :goto_0
.end method

.method private a(La/b/a/a/fg;I)V
    .locals 1

    new-instance v0, La/b/a/a/ff;

    invoke-direct {v0}, La/b/a/a/ff;-><init>()V

    invoke-direct {p0, p1, v0, p2}, La/b/a/a/fe;->a(La/b/a/a/fg;La/b/a/a/ff;I)V

    return-void
.end method

.method private a(La/b/a/a/fg;La/b/a/a/ff;I)V
    .locals 5

    iget-object v0, p0, La/b/a/a/fe;->a:La/b/a/a/fg;

    invoke-virtual {v0, p3}, La/b/a/a/fg;->a(I)La/b/a/a/ff;

    move-result-object v2

    invoke-virtual {v2}, La/b/a/a/ff;->size()I

    move-result v3

    iget-object v0, p0, La/b/a/a/fe;->a:La/b/a/a/fg;

    invoke-static {v0}, La/b/a/a/fg;->a(La/b/a/a/fg;)I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    if-le v0, p3, :cond_2

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    if-lt v1, v3, :cond_0

    :goto_1
    return-void

    :cond_0
    new-instance v4, La/b/a/a/ff;

    invoke-direct {v4, p2}, La/b/a/a/ff;-><init>(La/b/a/a/ff;)V

    if-eqz p2, :cond_1

    invoke-virtual {v2, v1}, La/b/a/a/ff;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/b/a/a/du;

    invoke-virtual {v4, v0}, La/b/a/a/ff;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, p3, 0x1

    invoke-direct {p0, p1, v4, v0}, La/b/a/a/fe;->a(La/b/a/a/fg;La/b/a/a/ff;I)V

    :cond_1
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_0

    :cond_2
    invoke-direct {p0, p1, p2, p3}, La/b/a/a/fe;->b(La/b/a/a/fg;La/b/a/a/ff;I)V

    goto :goto_1
.end method

.method private b(La/b/a/a/fg;)Ljava/util/List;
    .locals 10

    const/4 v1, 0x0

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    invoke-static {p1}, La/b/a/a/fg;->b(La/b/a/a/fg;)I

    move-result v4

    invoke-static {p1}, La/b/a/a/fg;->a(La/b/a/a/fg;)I

    move-result v5

    move v2, v1

    :goto_0
    if-lt v2, v4, :cond_0

    return-object v3

    :cond_0
    new-instance v6, La/b/a/a/fd;

    iget-object v0, p0, La/b/a/a/fe;->b:Ljava/lang/reflect/Constructor;

    invoke-direct {v6, v0}, La/b/a/a/fd;-><init>(Ljava/lang/reflect/Constructor;)V

    move v0, v1

    :goto_1
    if-lt v0, v5, :cond_1

    invoke-interface {v3, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_0

    :cond_1
    invoke-virtual {p1, v0, v2}, La/b/a/a/fg;->a(II)La/b/a/a/du;

    move-result-object v7

    invoke-interface {v7}, La/b/a/a/du;->b()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v7}, La/b/a/a/du;->a()Ljava/lang/Object;

    move-result-object v9

    invoke-virtual {v6, v9}, La/b/a/a/fd;->a(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_2

    new-instance v0, La/b/a/a/ai;

    const-string v2, "Parameter \'%s\' is a duplicate in %s"

    const/4 v3, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    aput-object v8, v3, v1

    const/4 v1, 0x1

    iget-object v4, p0, La/b/a/a/fe;->b:Ljava/lang/reflect/Constructor;

    aput-object v4, v3, v1

    invoke-direct {v0, v2, v3}, La/b/a/a/ai;-><init>(Ljava/lang/String;[Ljava/lang/Object;)V

    throw v0

    :cond_2
    invoke-virtual {v6, v7}, La/b/a/a/fd;->a(La/b/a/a/du;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_1
.end method

.method private b(La/b/a/a/fg;La/b/a/a/ff;I)V
    .locals 8

    const/4 v2, 0x0

    iget-object v0, p0, La/b/a/a/fe;->a:La/b/a/a/fg;

    invoke-virtual {v0, p3}, La/b/a/a/fg;->a(I)La/b/a/a/ff;

    move-result-object v4

    invoke-virtual {p2}, La/b/a/a/ff;->size()I

    move-result v5

    invoke-virtual {v4}, La/b/a/a/ff;->size()I

    move-result v6

    move v3, v2

    :goto_0
    if-lt v3, v6, :cond_0

    return-void

    :cond_0
    move v1, v2

    :goto_1
    if-lt v1, v5, :cond_1

    invoke-virtual {p1, p3}, La/b/a/a/fg;->a(I)La/b/a/a/ff;

    move-result-object v1

    invoke-virtual {v4, v3}, La/b/a/a/ff;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/b/a/a/du;

    invoke-virtual {v1, v0}, La/b/a/a/ff;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v3, 0x1

    move v3, v0

    goto :goto_0

    :cond_1
    invoke-virtual {p1, v1}, La/b/a/a/fg;->a(I)La/b/a/a/ff;

    move-result-object v7

    invoke-virtual {p2, v1}, La/b/a/a/ff;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La/b/a/a/du;

    invoke-virtual {v7, v0}, La/b/a/a/ff;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_1
.end method

.method private c()Ljava/util/List;
    .locals 3

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, La/b/a/a/fd;

    iget-object v2, p0, La/b/a/a/fe;->b:Ljava/lang/reflect/Constructor;

    invoke-direct {v1, v2}, La/b/a/a/fd;-><init>(Ljava/lang/reflect/Constructor;)V

    invoke-virtual {p0}, La/b/a/a/fe;->a()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_0
    return-object v0
.end method


# virtual methods
.method public a(La/b/a/a/du;I)V
    .locals 1

    iget-object v0, p0, La/b/a/a/fe;->a:La/b/a/a/fg;

    invoke-virtual {v0, p1, p2}, La/b/a/a/fg;->a(La/b/a/a/du;I)V

    return-void
.end method

.method public a()Z
    .locals 2

    iget-object v0, p0, La/b/a/a/fe;->b:Ljava/lang/reflect/Constructor;

    invoke-virtual {v0}, Ljava/lang/reflect/Constructor;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v0

    iget-object v1, p0, La/b/a/a/fe;->a:La/b/a/a/fg;

    invoke-static {v1}, La/b/a/a/fg;->a(La/b/a/a/fg;)I

    move-result v1

    array-length v0, v0

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    :goto_0
    return v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public b()Ljava/util/List;
    .locals 1

    new-instance v0, La/b/a/a/fg;

    invoke-direct {v0}, La/b/a/a/fg;-><init>()V

    invoke-direct {p0, v0}, La/b/a/a/fe;->a(La/b/a/a/fg;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method
