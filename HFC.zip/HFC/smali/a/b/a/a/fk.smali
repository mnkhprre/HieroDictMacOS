.class La/b/a/a/fk;
.super Ljava/lang/Object;


# instance fields
.field private final a:La/b/a/a/cn;

.field private final b:La/b/a/a/ct;

.field private final c:La/b/a/a/ct;

.field private final d:La/b/a/a/dj;

.field private final e:Z


# direct methods
.method public constructor <init>(La/b/a/a/cn;La/b/a/a/dj;La/b/a/a/ct;La/b/a/a/ct;Z)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p5, p0, La/b/a/a/fk;->e:Z

    iput-object p1, p0, La/b/a/a/fk;->a:La/b/a/a/cn;

    iput-object p3, p0, La/b/a/a/fk;->b:La/b/a/a/ct;

    iput-object p2, p0, La/b/a/a/fk;->d:La/b/a/a/dj;

    iput-object p4, p0, La/b/a/a/fk;->c:La/b/a/a/ct;

    return-void
.end method


# virtual methods
.method public a()La/b/a/a/cn;
    .locals 1

    iget-object v0, p0, La/b/a/a/fk;->a:La/b/a/a/cn;

    return-object v0
.end method

.method public b()La/b/a/a/ey;
    .locals 2

    new-instance v0, La/b/a/a/dn;

    iget-object v1, p0, La/b/a/a/fk;->d:La/b/a/a/dj;

    invoke-direct {v0, v1}, La/b/a/a/dn;-><init>(La/b/a/a/dj;)V

    return-object v0
.end method

.method public c()Z
    .locals 1

    iget-boolean v0, p0, La/b/a/a/fk;->e:Z

    return v0
.end method

.method public d()La/b/a/t;
    .locals 2

    iget-object v0, p0, La/b/a/a/fk;->b:La/b/a/a/ct;

    if-eqz v0, :cond_0

    iget-object v0, p0, La/b/a/a/fk;->b:La/b/a/a/ct;

    invoke-interface {v0}, La/b/a/a/ct;->g()La/b/a/a/ak;

    move-result-object v0

    const-class v1, La/b/a/t;

    invoke-interface {v0, v1}, La/b/a/a/ak;->a(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object v0

    check-cast v0, La/b/a/t;

    :goto_0
    return-object v0

    :cond_0
    const/4 v0, 0x0

    goto :goto_0
.end method

.method public e()La/b/a/a/ct;
    .locals 1

    iget-object v0, p0, La/b/a/a/fk;->b:La/b/a/a/ct;

    return-object v0
.end method

.method public f()La/b/a/a/ct;
    .locals 1

    iget-object v0, p0, La/b/a/a/fk;->c:La/b/a/a/ct;

    return-object v0
.end method
