.class La/a/a/a/i$c;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La/a/a/a/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "c"
.end annotation


# instance fields
.field private final a:Landroid/graphics/Matrix;

.field final b:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private c:F

.field private d:F

.field private e:F

.field private f:F

.field private g:F

.field private h:F

.field private i:F

.field private final j:Landroid/graphics/Matrix;

.field private k:I

.field private l:[I

.field private m:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, La/a/a/a/i$c;->a:Landroid/graphics/Matrix;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/a/a/a/i$c;->b:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput v0, p0, La/a/a/a/i$c;->c:F

    iput v0, p0, La/a/a/a/i$c;->d:F

    iput v0, p0, La/a/a/a/i$c;->e:F

    const/high16 v1, 0x3f800000    # 1.0f

    iput v1, p0, La/a/a/a/i$c;->f:F

    iput v1, p0, La/a/a/a/i$c;->g:F

    iput v0, p0, La/a/a/a/i$c;->h:F

    iput v0, p0, La/a/a/a/i$c;->i:F

    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, La/a/a/a/i$c;->j:Landroid/graphics/Matrix;

    const/4 v0, 0x0

    iput-object v0, p0, La/a/a/a/i$c;->m:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(La/a/a/a/i$c;Landroid/support/v4/util/ArrayMap;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "La/a/a/a/i$c;",
            "Landroid/support/v4/util/ArrayMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, La/a/a/a/i$c;->a:Landroid/graphics/Matrix;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La/a/a/a/i$c;->b:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput v0, p0, La/a/a/a/i$c;->c:F

    iput v0, p0, La/a/a/a/i$c;->d:F

    iput v0, p0, La/a/a/a/i$c;->e:F

    const/high16 v1, 0x3f800000    # 1.0f

    iput v1, p0, La/a/a/a/i$c;->f:F

    iput v1, p0, La/a/a/a/i$c;->g:F

    iput v0, p0, La/a/a/a/i$c;->h:F

    iput v0, p0, La/a/a/a/i$c;->i:F

    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, La/a/a/a/i$c;->j:Landroid/graphics/Matrix;

    const/4 v0, 0x0

    iput-object v0, p0, La/a/a/a/i$c;->m:Ljava/lang/String;

    iget v0, p1, La/a/a/a/i$c;->c:F

    iput v0, p0, La/a/a/a/i$c;->c:F

    iget v0, p1, La/a/a/a/i$c;->d:F

    iput v0, p0, La/a/a/a/i$c;->d:F

    iget v0, p1, La/a/a/a/i$c;->e:F

    iput v0, p0, La/a/a/a/i$c;->e:F

    iget v0, p1, La/a/a/a/i$c;->f:F

    iput v0, p0, La/a/a/a/i$c;->f:F

    iget v0, p1, La/a/a/a/i$c;->g:F

    iput v0, p0, La/a/a/a/i$c;->g:F

    iget v0, p1, La/a/a/a/i$c;->h:F

    iput v0, p0, La/a/a/a/i$c;->h:F

    iget v0, p1, La/a/a/a/i$c;->i:F

    iput v0, p0, La/a/a/a/i$c;->i:F

    iget-object v0, p1, La/a/a/a/i$c;->l:[I

    iput-object v0, p0, La/a/a/a/i$c;->l:[I

    iget-object v0, p1, La/a/a/a/i$c;->m:Ljava/lang/String;

    iput-object v0, p0, La/a/a/a/i$c;->m:Ljava/lang/String;

    iget v0, p1, La/a/a/a/i$c;->k:I

    iput v0, p0, La/a/a/a/i$c;->k:I

    iget-object v0, p0, La/a/a/a/i$c;->m:Ljava/lang/String;

    if-eqz v0, :cond_0

    invoke-virtual {p2, v0, p0}, Landroid/support/v4/util/SimpleArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    iget-object v0, p0, La/a/a/a/i$c;->j:Landroid/graphics/Matrix;

    iget-object v1, p1, La/a/a/a/i$c;->j:Landroid/graphics/Matrix;

    invoke-virtual {v0, v1}, Landroid/graphics/Matrix;->set(Landroid/graphics/Matrix;)V

    iget-object p1, p1, La/a/a/a/i$c;->b:Ljava/util/ArrayList;

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_5

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    instance-of v2, v1, La/a/a/a/i$c;

    if-eqz v2, :cond_1

    check-cast v1, La/a/a/a/i$c;

    iget-object v2, p0, La/a/a/a/i$c;->b:Ljava/util/ArrayList;

    new-instance v3, La/a/a/a/i$c;

    invoke-direct {v3, v1, p2}, La/a/a/a/i$c;-><init>(La/a/a/a/i$c;Landroid/support/v4/util/ArrayMap;)V

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_1
    instance-of v2, v1, La/a/a/a/i$b;

    if-eqz v2, :cond_2

    new-instance v2, La/a/a/a/i$b;

    check-cast v1, La/a/a/a/i$b;

    invoke-direct {v2, v1}, La/a/a/a/i$b;-><init>(La/a/a/a/i$b;)V

    goto :goto_1

    :cond_2
    instance-of v2, v1, La/a/a/a/i$a;

    if-eqz v2, :cond_4

    new-instance v2, La/a/a/a/i$a;

    check-cast v1, La/a/a/a/i$a;

    invoke-direct {v2, v1}, La/a/a/a/i$a;-><init>(La/a/a/a/i$a;)V

    :goto_1
    iget-object v1, p0, La/a/a/a/i$c;->b:Ljava/util/ArrayList;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, v2, La/a/a/a/i$d;->b:Ljava/lang/String;

    if-eqz v1, :cond_3

    invoke-virtual {p2, v1, v2}, Landroid/support/v4/util/SimpleArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3
    :goto_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_4
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Unknown object in the tree!"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_5
    return-void
.end method

.method static synthetic a(La/a/a/a/i$c;)I
    .locals 0

    iget p0, p0, La/a/a/a/i$c;->k:I

    return p0
.end method

.method private a(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;)V
    .locals 3

    const/4 v0, 0x0

    iput-object v0, p0, La/a/a/a/i$c;->l:[I

    iget v0, p0, La/a/a/a/i$c;->c:F

    const-string v1, "rotation"

    const/4 v2, 0x5

    invoke-static {p1, p2, v1, v2, v0}, La/a/a/a/f;->a(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v0

    iput v0, p0, La/a/a/a/i$c;->c:F

    iget v0, p0, La/a/a/a/i$c;->d:F

    const/4 v1, 0x1

    invoke-virtual {p1, v1, v0}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v0

    iput v0, p0, La/a/a/a/i$c;->d:F

    iget v0, p0, La/a/a/a/i$c;->e:F

    const/4 v1, 0x2

    invoke-virtual {p1, v1, v0}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v0

    iput v0, p0, La/a/a/a/i$c;->e:F

    iget v0, p0, La/a/a/a/i$c;->f:F

    const-string v1, "scaleX"

    const/4 v2, 0x3

    invoke-static {p1, p2, v1, v2, v0}, La/a/a/a/f;->a(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v0

    iput v0, p0, La/a/a/a/i$c;->f:F

    iget v0, p0, La/a/a/a/i$c;->g:F

    const-string v1, "scaleY"

    const/4 v2, 0x4

    invoke-static {p1, p2, v1, v2, v0}, La/a/a/a/f;->a(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v0

    iput v0, p0, La/a/a/a/i$c;->g:F

    iget v0, p0, La/a/a/a/i$c;->h:F

    const-string v1, "translateX"

    const/4 v2, 0x6

    invoke-static {p1, p2, v1, v2, v0}, La/a/a/a/f;->a(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v0

    iput v0, p0, La/a/a/a/i$c;->h:F

    iget v0, p0, La/a/a/a/i$c;->i:F

    const-string v1, "translateY"

    const/4 v2, 0x7

    invoke-static {p1, p2, v1, v2, v0}, La/a/a/a/f;->a(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result p2

    iput p2, p0, La/a/a/a/i$c;->i:F

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_0

    iput-object p1, p0, La/a/a/a/i$c;->m:Ljava/lang/String;

    :cond_0
    invoke-direct {p0}, La/a/a/a/i$c;->b()V

    return-void
.end method

.method static synthetic b(La/a/a/a/i$c;)Landroid/graphics/Matrix;
    .locals 0

    iget-object p0, p0, La/a/a/a/i$c;->a:Landroid/graphics/Matrix;

    return-object p0
.end method

.method private b()V
    .locals 4

    iget-object v0, p0, La/a/a/a/i$c;->j:Landroid/graphics/Matrix;

    invoke-virtual {v0}, Landroid/graphics/Matrix;->reset()V

    iget-object v0, p0, La/a/a/a/i$c;->j:Landroid/graphics/Matrix;

    iget v1, p0, La/a/a/a/i$c;->d:F

    neg-float v1, v1

    iget v2, p0, La/a/a/a/i$c;->e:F

    neg-float v2, v2

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    iget-object v0, p0, La/a/a/a/i$c;->j:Landroid/graphics/Matrix;

    iget v1, p0, La/a/a/a/i$c;->f:F

    iget v2, p0, La/a/a/a/i$c;->g:F

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Matrix;->postScale(FF)Z

    iget-object v0, p0, La/a/a/a/i$c;->j:Landroid/graphics/Matrix;

    iget v1, p0, La/a/a/a/i$c;->c:F

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2, v2}, Landroid/graphics/Matrix;->postRotate(FFF)Z

    iget-object v0, p0, La/a/a/a/i$c;->j:Landroid/graphics/Matrix;

    iget v1, p0, La/a/a/a/i$c;->h:F

    iget v2, p0, La/a/a/a/i$c;->d:F

    add-float/2addr v1, v2

    iget v2, p0, La/a/a/a/i$c;->i:F

    iget v3, p0, La/a/a/a/i$c;->e:F

    add-float/2addr v2, v3

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    return-void
.end method

.method static synthetic c(La/a/a/a/i$c;)Landroid/graphics/Matrix;
    .locals 0

    iget-object p0, p0, La/a/a/a/i$c;->j:Landroid/graphics/Matrix;

    return-object p0
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, La/a/a/a/i$c;->m:Ljava/lang/String;

    return-object v0
.end method

.method public a(Landroid/content/res/Resources;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;Lorg/xmlpull/v1/XmlPullParser;)V
    .locals 1

    sget-object v0, La/a/a/a/a;->b:[I

    invoke-static {p1, p3, p2, v0}, La/a/a/a/g;->a(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    invoke-direct {p0, p1, p4}, La/a/a/a/i$c;->a(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;)V

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    return-void
.end method
